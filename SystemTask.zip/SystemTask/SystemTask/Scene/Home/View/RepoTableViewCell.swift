//
//  RepoTableViewCell.swift
//  SystemTask
//
//  Created by abdelrahman elabd on 21/03/2023.
//

import UIKit

class RepoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var repoImageView : UIImageView!
    @IBOutlet weak var repoNameLBL : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
