//
//  Home.swift
//  SystemTask
//
//  Created by abdelrahman elabd on 21/03/2023.
//

import SwiftUI

struct Home: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
